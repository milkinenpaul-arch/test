/* Datatour BF2026 — page-scoped production interactions. */
(()=>{'use strict';
function initDatatourBF26(){
const root=document.getElementById('dt-bf26');
if(!root||root.dataset.dtInitialized==='true')return;
root.dataset.dtInitialized='true';
const $=s=>root.querySelector(s),$$=s=>Array.from(root.querySelectorAll(s));
const cfg=window.DatatourBF26||{};
const escapeHTML=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dtIconSVG={"baby": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M9 12h.01\" />\n  <path d=\"M15 12h.01\" />\n  <path d=\"M10 16c.5.3 1.2.5 2 .5s1.5-.2 2-.5\" />\n  <path d=\"M19 6.3a9 9 0 0 1 1.8 3.9 2 2 0 0 1 0 3.6 9 9 0 0 1-17.6 0 2 2 0 0 1 0-3.6A9 9 0 0 1 12 3c2 0 3.5 1.1 3.5 2.5s-.9 2.5-2 2.5c-.8 0-1.5-.4-1.5-1\" />\n</svg>", "bed-double": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8\" />\n  <path d=\"M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4\" />\n  <path d=\"M12 4v6\" />\n  <path d=\"M2 18h20\" />\n</svg>", "building-2": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z\" />\n  <path d=\"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2\" />\n  <path d=\"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2\" />\n  <path d=\"M10 6h4\" />\n  <path d=\"M10 10h4\" />\n  <path d=\"M10 14h4\" />\n  <path d=\"M10 18h4\" />\n</svg>", "calendar-check": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M8 2v4\" />\n  <path d=\"M16 2v4\" />\n  <rect width=\"18\" height=\"18\" x=\"3\" y=\"4\" rx=\"2\" />\n  <path d=\"M3 10h18\" />\n  <path d=\"m9 16 2 2 4-4\" />\n</svg>", "calendar-days": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M8 2v4\" />\n  <path d=\"M16 2v4\" />\n  <rect width=\"18\" height=\"18\" x=\"3\" y=\"4\" rx=\"2\" />\n  <path d=\"M3 10h18\" />\n  <path d=\"M8 14h.01\" />\n  <path d=\"M12 14h.01\" />\n  <path d=\"M16 14h.01\" />\n  <path d=\"M8 18h.01\" />\n  <path d=\"M12 18h.01\" />\n  <path d=\"M16 18h.01\" />\n</svg>", "check-check": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M18 6 7 17l-5-5\" />\n  <path d=\"m22 10-7.5 7.5L13 16\" />\n</svg>", "clipboard-check": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <rect width=\"8\" height=\"4\" x=\"8\" y=\"2\" rx=\"1\" ry=\"1\" />\n  <path d=\"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2\" />\n  <path d=\"m9 14 2 2 4-4\" />\n</svg>", "clipboard-list": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <rect width=\"8\" height=\"4\" x=\"8\" y=\"2\" rx=\"1\" ry=\"1\" />\n  <path d=\"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2\" />\n  <path d=\"M12 11h4\" />\n  <path d=\"M12 16h4\" />\n  <path d=\"M8 11h.01\" />\n  <path d=\"M8 16h.01\" />\n</svg>", "compass": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z\" />\n  <circle cx=\"12\" cy=\"12\" r=\"10\" />\n</svg>", "file-check-2": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4\" />\n  <path d=\"M14 2v4a2 2 0 0 0 2 2h4\" />\n  <path d=\"m3 15 2 2 4-4\" />\n</svg>", "file-pen-line": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"m18 5-2.414-2.414A2 2 0 0 0 14.172 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2\" />\n  <path d=\"M21.378 12.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z\" />\n  <path d=\"M8 18h1\" />\n</svg>", "heart": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z\" />\n</svg>", "image-plus": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M16 5h6\" />\n  <path d=\"M19 2v6\" />\n  <path d=\"M21 11.5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7.5\" />\n  <path d=\"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21\" />\n  <circle cx=\"9\" cy=\"9\" r=\"2\" />\n</svg>", "layout-list": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <rect width=\"7\" height=\"7\" x=\"3\" y=\"3\" rx=\"1\" />\n  <rect width=\"7\" height=\"7\" x=\"3\" y=\"14\" rx=\"1\" />\n  <path d=\"M14 4h7\" />\n  <path d=\"M14 9h7\" />\n  <path d=\"M14 15h7\" />\n  <path d=\"M14 20h7\" />\n</svg>", "map-pin": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0\" />\n  <circle cx=\"12\" cy=\"10\" r=\"3\" />\n</svg>", "menu": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <line x1=\"4\" x2=\"20\" y1=\"12\" y2=\"12\" />\n  <line x1=\"4\" x2=\"20\" y1=\"6\" y2=\"6\" />\n  <line x1=\"4\" x2=\"20\" y1=\"18\" y2=\"18\" />\n</svg>", "message-square": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z\" />\n</svg>", "plane": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z\" />\n</svg>", "receipt": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z\" />\n  <path d=\"M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8\" />\n  <path d=\"M12 17.5v-11\" />\n</svg>", "search": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <circle cx=\"11\" cy=\"11\" r=\"8\" />\n  <path d=\"m21 21-4.3-4.3\" />\n</svg>", "search-check": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"m8 11 2 2 4-4\" />\n  <circle cx=\"11\" cy=\"11\" r=\"8\" />\n  <path d=\"m21 21-4.3-4.3\" />\n</svg>", "sliders-horizontal": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <line x1=\"21\" x2=\"14\" y1=\"4\" y2=\"4\" />\n  <line x1=\"10\" x2=\"3\" y1=\"4\" y2=\"4\" />\n  <line x1=\"21\" x2=\"12\" y1=\"12\" y2=\"12\" />\n  <line x1=\"8\" x2=\"3\" y1=\"12\" y2=\"12\" />\n  <line x1=\"21\" x2=\"16\" y1=\"20\" y2=\"20\" />\n  <line x1=\"12\" x2=\"3\" y1=\"20\" y2=\"20\" />\n  <line x1=\"14\" x2=\"14\" y1=\"2\" y2=\"6\" />\n  <line x1=\"8\" x2=\"8\" y1=\"10\" y2=\"14\" />\n  <line x1=\"16\" x2=\"16\" y1=\"18\" y2=\"22\" />\n</svg>", "sparkles": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z\" />\n  <path d=\"M20 3v4\" />\n  <path d=\"M22 5h-4\" />\n  <path d=\"M4 17v2\" />\n  <path d=\"M5 18H3\" />\n</svg>", "users": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2\" />\n  <circle cx=\"9\" cy=\"7\" r=\"4\" />\n  <path d=\"M22 21v-2a4 4 0 0 0-3-3.87\" />\n  <path d=\"M16 3.13a4 4 0 0 1 0 7.75\" />\n</svg>", "wallet": "<svg class=\"dt-svg-icon\" aria-hidden=\"true\"\n \n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"1.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1\" />\n  <path d=\"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4\" />\n</svg>"};
dtIconSVG['arrow-up-right']='<svg class="dt-svg-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M6 18 18 6M6 6h12v12"/></svg>';
const icons=()=>$$('[data-dt-icon]').forEach(el=>{if(dtIconSVG[el.dataset.dtIcon])el.innerHTML=dtIconSVG[el.dataset.dtIcon];});
const scenarios=[{id:'family',name:'С детьми',icon:'baby',summer:'Пляж, удобный номер и отдых в ритме семьи.',winter:'Возраст детей, каникулы и удобный перелёт.'},{id:'couple',name:'Вдвоём и спокойно',icon:'heart',summer:'Море, спокойный ритм и время друг для друга.',winter:'Тёплая пауза и отдых без лишней спешки.'},{id:'friends',name:'Активно и компанией',icon:'users',summer:'Общие планы и удобное размещение для компании.',winter:'Новые впечатления и активная поездка вместе.'},{id:'discover',name:'Море и впечатления',icon:'compass',summer:'Пляж, прогулки и поездки за пределы отеля.',winter:'Знакомство с направлением и отдых у моря.'},{id:'service',name:'Комфорт и сервис',icon:'sparkles',summer:'Важные детали номера, питания и обслуживания.',winter:'Продуманный отдых и внимание к вашим пожеланиям.'}];
const seasons={summer:'Турция, лето 2027',winter:'Зимние направления'},budgets={all:'Бюджет без ограничений',rational:'Рациональный',comfort:'Комфорт',premium:'Премиальный'};
const priorities=Array.isArray(cfg.priority_hotels)?cfg.priority_hotels:[];
const hotels=priorities.slice(0,25);
const forms=$$('[data-lead-form]');
const state={season:'summer',scenario:'all',budget:'all',hotel:null};
const motion=()=>matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth';
function campaignState(now=Date.now()){
 const start=Date.parse(cfg.campaign?.start),end=Date.parse(cfg.campaign?.end);
 if(!Number.isFinite(start)||!Number.isFinite(end)||end<=start)return {status:'unknown',remaining:0};
 if(now<start)return {status:'before',remaining:start-now};
 if(now<end)return {status:'active',remaining:end-now};
 return {status:'ended',remaining:0};
}
function updateTimer(){
 const t=campaignState();
 const labels={unknown:'Проверим предложения на ваши даты',before:'До начала акции',active:'Акция идёт',ended:'Акция завершена'};
 $('#dt-campaign-status').textContent=labels[t.status];
 $('#dt-campaign-note').textContent=t.status==='ended'?'Акция 27–29 ноября завершилась. Подберём актуальные предложения на ваши даты.':'Предложения акции Datatour — 27–29 ноября 2026, время Минска.';
 const s=Math.max(0,Math.floor(t.remaining/1000));
 const values=[Math.floor(s/86400),Math.floor(s/3600)%24,Math.floor(s/60)%60,s%60];
 ['days','hours','minutes','seconds'].forEach((k,i)=>$('[data-time="'+k+'"]').textContent=String(values[i]).padStart(2,'0'));
 $('.dt-timer').setAttribute('aria-label',labels[t.status]);
 if(t.status==='ended'){
  $$('[data-goal="booking"]').forEach(a=>{a.dataset.goal='selection';if(a.firstChild?.nodeType===3)a.firstChild.textContent='Подобрать актуальный тур';});
  $$('[data-active-offers],[data-campaign-copy]').forEach(el=>el.hidden=true);
  $('#dt-h1').textContent='Подберём отдых на ваши даты';
  $('.dt-hero .dt-eyebrow').textContent='Datatour · Ваш следующий отпуск';
  $('#dt-request-title').textContent='Подготовим варианты для вашего отпуска';
  $('#dt-request .dt-intro').textContent='Укажите пожелания: проверим актуальные цену, наличие и условия для вашей поездки.';
  $$('a[data-goal=selection]').filter(a=>['#dt-request','#dt-quick-form'].includes(a.getAttribute('href'))||a.dataset.source==='search-manager').forEach(a=>{if(a.firstChild?.nodeType===3)a.firstChild.textContent='Подобрать актуальный тур';});
  forms.forEach(f=>{const o=f.elements.purpose.querySelector('option[value="booking"]');if(o)o.disabled=true;if(f.elements.purpose.value==='booking')f.elements.purpose.value='selection';});
  $$('[data-submit-label]').forEach(b=>{if(!b.disabled)b.textContent='Подобрать актуальный тур';});
  const idea=$('.dt-hero-idea');if(idea)idea.textContent='Подготовим актуальные варианты для вашего следующего отпуска.';
 }
}
function updateHeader(){
 const admin=document.getElementById('wpadminbar');
 const offset=admin&&getComputedStyle(admin).position==='fixed'?admin.getBoundingClientRect().height:0;
 root.style.setProperty('--dt-admin-offset',offset+'px');
 root.style.setProperty('--dt-anchor-offset',(offset+$('.dt-header').getBoundingClientRect().height+20)+'px');
}
if(typeof ResizeObserver!=='undefined')new ResizeObserver(updateHeader).observe($('.dt-header'));
window.addEventListener('resize',updateHeader,{passive:true});updateHeader();
function clearMessages(){forms.forEach(f=>{const box=f.querySelector('.dt-message');box.dataset.show='false';box.textContent='';});}
function message(form,text,kind){const box=form.querySelector('.dt-message');box.textContent=text;box.dataset.state=kind;box.dataset.show='true';}
function childrenChanged(form){const n=Number(form.elements.children.value);const field=form.querySelector('[data-ages-field]');field.hidden=n===0;form.elements.ages.disabled=n===0;form.elements.ages.required=n>0;}
function updateCarousel(kind){
 const track=$('#dt-'+kind+'-track');if(!track)return;
 const cards=Array.from(track.children).filter(c=>!c.hidden),rect=track.getBoundingClientRect();
 const visible=cards.map((c,i)=>({i,r:c.getBoundingClientRect()})).filter(x=>x.r.right>rect.left+5&&x.r.left<rect.right-5);
 const first=visible.length?visible[0].i+1:0,last=visible.length?visible[visible.length-1].i+1:0;
 const counter=$('#dt-'+kind+'-counter');if(counter)counter.textContent=cards.length?(first===last?first:first+'–'+last)+' / '+cards.length:'0 / 0';
 const prev=$('#dt-'+kind+'-prev'),next=$('#dt-'+kind+'-next');
 if(prev)prev.disabled=track.scrollLeft<5;if(next)next.disabled=track.scrollLeft+track.clientWidth>=track.scrollWidth-8||!cards.length;
}
function bindCarousel(kind){const track=$('#dt-'+kind+'-track');if(!track)return;
 for(const [direction,multiplier] of [['prev',-1],['next',1]]){const b=$('#dt-'+kind+'-'+direction);if(b)b.addEventListener('click',()=>track.scrollBy({left:multiplier*(track.clientWidth+18),behavior:motion()}));}
 track.addEventListener('scroll',()=>requestAnimationFrame(()=>updateCarousel(kind)),{passive:true});
 track.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();track.scrollBy({left:(e.key==='ArrowRight'?1:-1)*(track.clientWidth+18),behavior:motion()});}});
 if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>updateCarousel(kind)).observe(track);
}
function renderScenarios(){
 $$('[data-scenario-set]').forEach(c=>{c.innerHTML=scenarios.map(s=>'<button type="button" class="dt-scenario" data-scenario="'+s.id+'" aria-pressed="false"><span class="dt-icon"><i data-dt-icon="'+s.icon+'"></i></span><span class="dt-scenario-name">'+s.name+'</span><span class="dt-scenario-hint">'+s[c.dataset.scenarioSet]+'</span><span class="dt-scenario-check">Выбрать сценарий</span></button>').join('');});
 $('#dt-hotel-scenario').innerHTML='<option value="all">Любой сценарий</option>'+scenarios.map(s=>'<option value="'+s.id+'">'+s.name+'</option>').join('');
}
function renderHotels(){
 $('#dt-hotel-track').innerHTML=hotels.map(h=>'<article class="dt-hotel-card" data-hotel="'+h.id+'"><div class="dt-hotel-media"><span class="dt-hotel-category">'+h.category+'*</span><span class="dt-hotel-type">'+'Отель или сеть из списка'+'</span></div><div class="dt-hotel-body"><h3>'+escapeHTML(h.name)+'</h3><p>Укажите даты, состав туристов и пожелания к номеру. Проверим конкретный вариант и рассчитаем стоимость.</p><p>Цена и наличие — по индивидуальному запросу.</p><button type="button" class="dt-action" data-select-hotel="'+h.id+'">Рассчитать этот вариант</button></div></article>').join('');
}
function syncState(){
 const scenario=scenarios.find(x=>x.id===state.scenario);
 const description=seasons[state.season]+' · '+(scenario?scenario.name:'Любой сценарий')+' · '+budgets[state.budget];
 forms.forEach(f=>{
  f.elements.season.value=state.season;f.elements.scenario.value=state.scenario;f.elements.budgetLevel.value=state.budget;
  f.elements.hotelId.value=state.hotel?.id||'';f.elements.hotelLabel.value=state.hotel?.name||'';
  f.querySelector('[data-form-context]').textContent=description;
  f.querySelector('[data-selected-hotel]').hidden=!state.hotel;
  f.querySelector('[data-selected-name]').textContent=state.hotel?.name||'';
 });
 $('#dt-hotel-season').value=state.season;$('#dt-hotel-scenario').value=state.scenario;
 $$('[data-season]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.season===state.season)));
 $('#dt-panel-summer').hidden=state.season!=='summer';$('#dt-panel-winter').hidden=state.season!=='winter';
 $$('[data-scenario]').forEach(b=>{const chosen=b.dataset.scenario===state.scenario;b.setAttribute('aria-pressed',String(chosen));b.querySelector('.dt-scenario-check').textContent=chosen?'Выбрано':'Выбрать сценарий';});
 $$('[data-budget]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.budget===state.budget)));
 $('#dt-selection-label').textContent=description;
 const show=state.season==='summer';$('#dt-hotel-track').hidden=!show;$('#dt-hotel-footer').hidden=!show;$('#dt-empty').hidden=show;
 $('#dt-results').textContent=show?'Для индивидуального расчёта: '+hotels.length+' позиций':'Зимние варианты — по вашим пожеланиям';
 requestAnimationFrame(()=>updateCarousel('hotel'));
}
function changeSeason(season){state.season=season;if(state.hotel&&season==='winter')state.hotel=null;syncState();clearMessages();track('season',{season,source:'selection'});}
function moveTo(id,focus=false){const target=$(id);if(!target)return;updateHeader();target.scrollIntoView({behavior:motion(),block:'start'});if(focus)target.querySelector('input:not([type="hidden"]):not([name="website"])')?.focus({preventScroll:true});}
function setPurpose(goal,source){if(campaignState().status==='ended'&&goal==='booking')goal='selection';forms.forEach(f=>{f.elements.purpose.value=goal;f.elements.source.value=source||'page';const labels={selection:'Подобрать тур к распродаже',hotel:'Рассчитать выбранный отель',booking:'Записаться на бронирование'};const b=f.querySelector('[data-submit-label]');if(!b.disabled)b.textContent=campaignState().status==='ended'?'Подобрать актуальный тур':labels[goal];});}
function selectHotel(id,source){const h=priorities.find(x=>x.id===id);if(!h)return;state.hotel=h;state.season='summer';syncState();setPurpose('hotel',source);track('hotel',{hotelId:h.id,source});moveTo('#dt-request',true);}
// Consent stores preferences only. Form contents remain in memory, never analytics or storage.
const storageKey='dtbf26-consent-v1';let consent={analytics:false},hasChoice=false;
try{const stored=JSON.parse(localStorage.getItem(storageKey)||'null');if(stored&&stored.version===1){consent={analytics:stored.analytics===true};hasChoice=true;}}catch{}
const cookieDialog=$('#dt-cookie-dialog');
function openCookieSettings(){$('#dt-consent-analytics').checked=consent.analytics;if(cookieDialog.showModal)cookieDialog.showModal();else cookieDialog.setAttribute('open','');}
function closeCookieSettings(){if(cookieDialog.close)cookieDialog.close();else cookieDialog.removeAttribute('open');}
function saveConsent(next){const revoke=consent.analytics&&!next.analytics;consent=next;hasChoice=true;try{localStorage.setItem(storageKey,JSON.stringify({version:1,...consent,updatedAt:new Date().toISOString()}));}catch{}
 $('#dt-cookie-banner').hidden=true;closeCookieSettings();root.dispatchEvent(new CustomEvent('dtbf26:consent',{detail:{...consent}}));
 if(revoke){location.reload();return;}
}
function track(action,data={}){
 const safe={action,source:String(data.source||'page').slice(0,60)};
 for(const k of ['season','scenario','hotelId','purpose','network'])if(typeof data[k]==='string')safe[k]=data[k].slice(0,100);
 root.dispatchEvent(new CustomEvent('dtbf26:event',{detail:safe}));
 if(!consent.analytics)return;
 if(cfg.analytics?.ga_installed&&typeof window.gtag==='function')window.gtag('event','dtbf26_'+action,safe);
 if(typeof window.ym==='function')for(const id of cfg.analytics?.yandex_ids||[])window.ym(Number(id),'reachGoal','dtbf26_'+action,safe);
}
$('#dt-cookie-banner').hidden=hasChoice;
$$('[data-cookie-choice]').forEach(b=>b.addEventListener('click',()=>saveConsent({analytics:b.dataset.cookieChoice==='all'})));
$$('[data-cookie-settings]').forEach(b=>b.addEventListener('click',()=>openCookieSettings()));
$('#dt-cookie-save').addEventListener('click',()=>saveConsent({analytics:$('#dt-consent-analytics').checked}));
$('#dt-cookie-close').addEventListener('click',closeCookieSettings);
const viewer=$('#dt-viewer');let viewerTrigger=null;
function renderReviews(){const list=Array.isArray(cfg.reviews)?cfg.reviews:[];
 $('#dt-trust').hidden=list.length===0;
 $('#dt-review-track').innerHTML=list.map((r,i)=>'<article class="dt-review"><button type="button" class="dt-review-button" data-review="'+i+'" aria-label="Увеличить отзыв '+escapeHTML(r.author)+'"><img src="'+escapeHTML(r.image)+'" alt="Отзыв '+escapeHTML(r.author)+'" loading="lazy"></button><p class="dt-review-caption">'+escapeHTML(r.author)+(r.tripType?' · '+escapeHTML(r.tripType):'')+'</p></article>').join('');
 const links=cfg.review_links||{};
 $('.dt-review-links').innerHTML=(links.yandex&&links.google)?'<span>Больше отзывов в <a href="'+escapeHTML(links.yandex)+'" target="_blank" rel="noopener">Яндекс</a> и <a href="'+escapeHTML(links.google)+'" target="_blank" rel="noopener">Google</a></span>':'';
}
function closeViewer(){if(viewer.close)viewer.close();else viewer.removeAttribute('open');viewerTrigger?.focus();}
$('.dt-dialog-close').addEventListener('click',closeViewer);viewer.addEventListener('click',e=>{if(e.target===viewer)closeViewer();});
root.addEventListener('click',e=>{
 const menu=e.target.closest('.dt-menu-button');if(menu){const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Закрыть меню':'Открыть меню');$('#dt-navigation').dataset.open=String(open);updateHeader();return;}
 const season=e.target.closest('[data-season]');if(season){changeSeason(season.dataset.season);return;}
 const scenario=e.target.closest('[data-scenario]');if(scenario){state.scenario=state.scenario===scenario.dataset.scenario?'all':scenario.dataset.scenario;syncState();clearMessages();track('scenario',{scenario:state.scenario,source:'scenario'});return;}
 const budget=e.target.closest('[data-budget]');if(budget){state.budget=budget.dataset.budget;syncState();clearMessages();return;}
 const hotel=e.target.closest('[data-select-hotel],[data-select-priority]');if(hotel){selectHotel(hotel.dataset.selectHotel||hotel.dataset.selectPriority,hotel.dataset.selectPriority?'priority-list':'hotel-slider');return;}
 const remove=e.target.closest('[data-remove-hotel]');if(remove){state.hotel=null;syncState();setPurpose('selection','hotel-removed');return;}
 const review=e.target.closest('[data-review]');if(review){const r=cfg.reviews[Number(review.dataset.review)];if(!r)return;viewerTrigger=review;$('#dt-viewer-title').textContent=r.author;$('#dt-viewer-content').innerHTML='<img src="'+escapeHTML(r.image)+'" alt="Отзыв '+escapeHTML(r.author)+'"><p>'+escapeHTML(r.tripType||'')+'</p>';if(viewer.showModal)viewer.showModal();else viewer.setAttribute('open','');return;}
 const tracked=e.target.closest('[data-track]');if(tracked)track(tracked.dataset.track,{source:tracked.closest('.dt-header')?'header':'contacts',network:tracked.dataset.network||''});
 const anchor=e.target.closest('a[href^="#"]');if(anchor){const id=anchor.getAttribute('href');if(!$(id))return;e.preventDefault();if(anchor.dataset.goal){setPurpose(anchor.dataset.goal,anchor.dataset.source);if(anchor.dataset.goal==='booking')track('booking',{purpose:'booking',source:anchor.dataset.source});}
  moveTo(id,id==='#dt-request'||id==='#dt-quick-form');$('#dt-navigation').dataset.open='false';$('.dt-menu-button').setAttribute('aria-expanded','false');updateHeader();
 }
});
root.addEventListener('keydown',e=>{if(e.key==='Escape'){if(viewer.hasAttribute('open'))closeViewer();if(cookieDialog.hasAttribute('open'))closeCookieSettings();$$('.dt-phones[open]').forEach(d=>{d.open=false;d.querySelector('summary').focus();});$('#dt-navigation').dataset.open='false';$('.dt-menu-button').setAttribute('aria-expanded','false');updateHeader();}});
document.addEventListener('click',e=>$$('.dt-phones[open]').forEach(d=>{if(!d.contains(e.target))d.open=false;}));
$('.dt-tabs').addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const season=e.key==='Home'?'summer':e.key==='End'?'winter':state.season==='summer'?'winter':'summer';changeSeason(season);$('#dt-tab-'+season).focus();}});
$('#dt-hotel-season').addEventListener('change',e=>changeSeason(e.target.value));$('#dt-hotel-scenario').addEventListener('change',e=>{state.scenario=e.target.value;syncState();});$('#dt-reset-scenario').addEventListener('click',()=>{state.scenario='all';syncState();});
function validContact(v){v=v.trim();return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)||(/^\+?[\d\s()\-]{7,25}$/.test(v)&&v.replace(/\D/g,'').length>=7&&v.replace(/\D/g,'').length<=15)||/^@[A-Za-z0-9_]{3,32}$/.test(v)||/^(?:https?:\/\/)?t\.me\/[A-Za-z0-9_]{3,32}$/.test(v);}
function validateForm(f){let first=null;for(const field of ['contact','consent','ages']){const el=f.elements[field];let good=true,text='';
 if(field==='contact'){good=validContact(el.value);text='Введите телефон с кодом страны, email или Telegram @username.';}
 if(field==='consent'){good=el.checked;text='Нужно согласие на обработку персональных данных.';}
 if(field==='ages'&&Number(f.elements.children.value)>0){const ages=el.value.match(/\d+/g)||[];good=/^[0-9\s,;]+$/.test(el.value)&&ages.length===Number(f.elements.children.value)&&ages.every(n=>Number(n)<=17);text='Укажите возраст каждого ребёнка от 0 до 17 лет.';}
 el.setAttribute('aria-invalid',String(!good));const error=f.querySelector('#'+f.id.replace('-form','')+'-'+field+'-error');if(error)error.textContent=good?'':text;if(!good&&!first)first=el;
 }if(first){first.focus();return false;}return true;}
let contextPromise=null;
function getFormContext(refresh=false){if(refresh)contextPromise=null;if(contextPromise)return contextPromise;if(!cfg.ajaxUrl)return Promise.reject(new Error('Form configuration unavailable'));
 contextPromise=fetch(cfg.ajaxUrl+'?action=dtbf26_form_context',{credentials:'same-origin',cache:'no-store'}).then(async r=>{const j=await r.json();if(!r.ok||!j.success)throw new Error('Form context unavailable');return j.data;}).catch(e=>{contextPromise=null;throw e;});return contextPromise;
}
getFormContext().catch(()=>{});
function requestID(){return crypto.randomUUID?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('');}
async function submitForm(f){if(f._busy||!validateForm(f))return;const values=new FormData(f);const canonical=JSON.stringify(Array.from(values.entries()));
 if(f._sentPayload===canonical){message(f,'Заявка уже принята. Менеджер свяжется с вами.','success');return;}
 if(f._payload!==canonical){f._payload=canonical;f._requestId=requestID();}
 f._busy=true;f.setAttribute('aria-busy','true');const button=f.querySelector('[type="submit"]'),label=button.textContent;button.disabled=true;button.textContent='Отправляем…';message(f,'Отправляем вашу заявку…','loading');
 try{const context=await getFormContext();for(const k of ['nonce','issued','token'])values.append(k,context[k]);values.append('requestId',f._requestId);values.append('action','dtbf26_submit');
 const params=new URLSearchParams(location.search);for(const key of ['utm_source','utm_medium','utm_campaign','utm_term','utm_content'])if(params.has(key))values.append(key,params.get(key).slice(0,200));
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),45000);let response;
 try{response=await fetch(cfg.ajaxUrl,{method:'POST',body:values,credentials:'same-origin',signal:controller.signal});}finally{clearTimeout(timeout);}
 const result=await response.json();if(!response.ok||!result.success){if(result.data?.code==='expired_context')contextPromise=null;if(result.data?.code==='mail_failed'){f._payload=null;f._requestId=null;}throw new Error(result.data?.message||'Не удалось отправить заявку. Попробуйте ещё раз или позвоните менеджеру.');}
 f._sentPayload=canonical;message(f,result.data.message||'Спасибо! Заявка принята. Менеджер свяжется с вами.','success');track('form_accepted',{purpose:f.elements.purpose.value,source:f.elements.source.value});
 }catch(e){message(f,e.name==='AbortError'?'Не удалось получить ответ вовремя. Повторная отправка с теми же данными проверит статус заявки без дублирования.':e.message==='Form context unavailable'||e.message==='Form configuration unavailable'?'Не удалось подготовить отправку. Обновите страницу или позвоните менеджеру.':e instanceof SyntaxError||e instanceof TypeError?'Не удалось получить ответ сервера. Попробуйте ещё раз или позвоните менеджеру.':e.message,'error');}
 finally{f._busy=false;f.setAttribute('aria-busy','false');button.disabled=false;button.textContent=label;}
}
forms.forEach(f=>{f.elements.adults.value='2';childrenChanged(f);f.addEventListener('submit',e=>{e.preventDefault();submitForm(f);});f.elements.children.addEventListener('change',()=>childrenChanged(f));f.elements.season.addEventListener('change',e=>changeSeason(e.target.value));f.elements.purpose.addEventListener('change',()=>{setPurpose(f.elements.purpose.value,f.elements.source.value);if(f.elements.purpose.value==='booking')track('booking',{purpose:'booking',source:f.elements.source.value});});
 f.addEventListener('input',e=>{clearMessages();if(['contact','direction','period','duration','adults','children','ages','budgetAmount','wishes'].includes(e.target.name)){for(const other of forms){if(other!==f)other.elements[e.target.name].value=e.target.value;childrenChanged(other);}}});
});
const payments=Array.isArray(cfg.payments)?cfg.payments:[];$('#dt-payments').innerHTML=payments.map(p=>'<img src="'+escapeHTML(p.image)+'" alt="'+escapeHTML(p.name)+'" loading="lazy">').join('');$('#dt-payments').hidden=payments.length===0;
renderScenarios();renderHotels();renderReviews();syncState();bindCarousel('hotel');bindCarousel('review');icons();updateTimer();setInterval(updateTimer,1000);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initDatatourBF26,{once:true});else initDatatourBF26();
})();
