<?php
/**
 * Plugin Name: Datatour BF2026 Landing
 * Description: Datatour landing shortcode [datatour_bf26] and optional standalone page template. Demo forms only.
 * Version: 1.0.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Text Domain: datatour-bf26
 */
if (!defined('ABSPATH')) { exit; }
function dtbf26_enqueue_assets() {
    $base = plugin_dir_url(__FILE__);
    wp_enqueue_style('dtbf26-shell', $base . 'assets/shell.css', array(), (string) filemtime(__DIR__ . '/assets/shell.css'));
    wp_enqueue_style('dtbf26-style', $base . 'assets/datatour-bf26.css', array('dtbf26-shell'), (string) filemtime(__DIR__ . '/assets/datatour-bf26.css'));
    wp_enqueue_script('dtbf26-script', $base . 'assets/datatour-bf26.js', array(), (string) filemtime(__DIR__ . '/assets/datatour-bf26.js'), true);
}
add_action('wp_enqueue_scripts', function () {
    if (!is_singular()) { return; }
    $post = get_queried_object();
    if ($post instanceof WP_Post && has_shortcode($post->post_content, 'datatour_bf26')) {
        dtbf26_enqueue_assets();
    }
});
add_shortcode('datatour_bf26', function () {
    static $rendered = false;
    if ($rendered) { return ''; }
    $rendered = true;
    dtbf26_enqueue_assets();
    $html = file_get_contents(__DIR__ . '/assets/datatour-bf26.html');
    return $html === false ? '' : $html;
});
add_filter('theme_page_templates', function ($templates) {
    $templates['datatour-bf26/landing.php'] = 'Datatour — отдельный лендинг';
    return $templates;
});
add_filter('template_include', function ($template) {
    if (is_singular('page') && get_page_template_slug(get_queried_object_id()) === 'datatour-bf26/landing.php') {
        return __DIR__ . '/templates/landing.php';
    }
    return $template;
});
