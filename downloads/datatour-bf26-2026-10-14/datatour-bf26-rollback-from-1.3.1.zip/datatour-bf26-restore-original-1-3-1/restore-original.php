<?php
/** Plugin Name: Datatour — Restore original page implementation (1.3.1)
 * Description: Activation restores the checksummed pre-update landing plugin (demo forms). Activate only for rollback. Does not delete articles or change page URL/theme.
 * Version: 1.0.0
 */
if (!defined('ABSPATH')) { exit; }
function dtbf26restore_original() {
 if (!current_user_can('activate_plugins')) { throw new Exception('Administrator activation required.'); }
 $m=json_decode(file_get_contents(__DIR__.'/manifest.json'),true);
 $base=realpath(WP_PLUGIN_DIR);$root=realpath(WP_PLUGIN_DIR.'/datatour-bf26-compatible');
 if (!$root || strpos($root.'/', $base.'/')!==0) { throw new Exception('Invalid plugin root.'); }
 $main=$root.'/datatour-bf26.php';$sha=hash_file('sha256',$main);
 if ($sha===$m['original_main']) { return; }
 if ($sha!==$m['current_main']) { throw new Exception('Plugin changed since snapshot; restore cancelled.'); }
 foreach ($m['original_resources'] as $file=>$expected) {
  if (!is_file($root.'/'.$file) || hash_file('sha256',$root.'/'.$file)!==$expected) { throw new Exception('Original resource changed; restore cancelled: '.$file); }
 }
 $saved=file_get_contents(__DIR__.'/original-data.php');
 $old=base64_decode(substr($saved,strlen("<?php exit; ?>\n")),true);
 if ($old===false || hash('sha256',$old)!==$m['original_main']) { throw new Exception('Backup checksum failed.'); }
 $tmp=$main.'.dtbf26-restore';
 if (file_put_contents($tmp,$old)!==strlen($old) || hash_file('sha256',$tmp)!==$m['original_main']) { @unlink($tmp);throw new Exception('Restore staging failed.'); }
 @chmod($tmp,0644);
 if (!rename($tmp,$main)) { @unlink($tmp);throw new Exception('Atomic restore failed.'); }
 if (function_exists('opcache_invalidate')) { @opcache_invalidate($main,true); }
 wp_clear_scheduled_hook('dtbf26_cleanup_requests');
 update_option('dtbf26_deployment',array('status'=>'restored_original','time'=>time()),false);
 if (function_exists('wp_clean_plugins_cache')) { wp_clean_plugins_cache(true); }
}
register_activation_hook(__FILE__,'dtbf26restore_original');
